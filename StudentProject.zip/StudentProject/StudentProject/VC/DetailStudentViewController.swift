//
//  DetailStudentViewController.swift
//  StudentProject
//
//  Created by Razan alshatti on 03/03/2024.
//

import UIKit
import SnapKit

class DetailStudentViewController: UIViewController {
    
    var studentprofile: StudentProfile?
    
    let studentNameLabel = UILabel()
    let studentGPALabel = UILabel()
    let studentImageView = UIImageView()



    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setupLAyout()
        configureWithStudentProfile()

        // Do any additional setup after loading the view.
    }
    
    func setupViews(){
        view.backgroundColor = .white
        
        studentNameLabel.font = .systemFont(ofSize: 16, weight: .bold)
        studentGPALabel.font = .systemFont(ofSize: 16, weight: .medium)
        
        view.addSubview(studentNameLabel)
        view.addSubview(studentGPALabel)
        view.addSubview(studentImageView)

    }
    
    func setupLAyout(){
        
        studentImageView.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide).offset(20)
            make.centerX.equalToSuperview()
            make.width.height.equalTo(100)
        }
        
        studentNameLabel.snp.makeConstraints { make in
            make.top.equalTo(studentImageView.snp.bottom).offset(20)
            make.centerX.equalToSuperview()
        }
        
        studentGPALabel.snp.makeConstraints { make in
            make.top.equalTo(studentNameLabel.snp.bottom).offset(20)
            make.centerX.equalToSuperview()
        }
        
        
    }
    
    func configureWithStudentProfile(){
        studentNameLabel.text = "Student Name : \(studentprofile?.studentName ?? "")"
        studentGPALabel.text = "GPA : \(studentprofile?.studentGPA ?? 0.0)"
        studentImageView.image = UIImage(named: studentprofile?.studentImage ?? "Razan")
    
    }
    


}
