//
//  ViewController.swift
//  StudentProject
//
//  Created by Razan alshatti on 03/03/2024.
//

import UIKit

class StudentTableViewController: UITableViewController {
    
    var studentProfile: [StudentProfile] = [
        StudentProfile(studentName: "Razan", studentGPA: 3.00, studentImage: "Razan"),
        StudentProfile(studentName: "Nada", studentGPA: 4.00, studentImage: "Nada"),
        StudentProfile(studentName: "Fatma", studentGPA: 4.00, studentImage: "Fatma")]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return studentProfile.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let student = studentProfile[indexPath.row]
        
        cell.textLabel?.text = "Student name: \(student.studentName), student GPA: \(student.studentGPA)"
        
        cell.imageView?.image = UIImage(named: student.studentImage)
        
        
        return cell
    
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let detailVC = DetailStudentViewController()
        
        let selectedStudent = studentProfile[indexPath.row]
        detailVC.studentprofile = selectedStudent
        
        navigationController?.pushViewController(detailVC, animated: true)
    }
    
    


}

