//
//  StudentProfile.swift
//  StudentProject
//
//  Created by Razan alshatti on 03/03/2024.
//

import Foundation

struct StudentProfile{
    var studentName: String
    var studentGPA: Double
    var studentImage: String
}

